#include "BoundedBuffer.h"
#include <cstring> //c_str
#include <assert.h> //assert

using namespace std;
BoundedBuffer::BoundedBuffer (int _cap) : cap(_cap) {
    // modify as needed
}

BoundedBuffer::~BoundedBuffer () {
    // modify as needed
}

void BoundedBuffer::push (char* msg, int size) {
    // 1. Convert the incoming byte sequence given by msg and size into a vector<char>, constructor for vector
    std::vector<char> vec(msg,msg+size);

    // 2. Wait until there is room in the queue (i.e., queue.size is less than cap)
    // using cv for not full, acquire the lock
    std::unique_lock lk(m);
    cvNotFull.wait(lk,[this]{return int (q.size()) <= cap;});
    
    // 3. Then push the vector at the end of the queue
    // unlock the unique lock
    q.push(vec);
    lk.unlock();
    // 4. Wake up threads that were waiting for push, notify the cv for not empty
    cvNotEmpty.notify_one();
}

int BoundedBuffer::pop (char* msg, int size) {
    // 1. Wait until the queue has at least 1 item
    // using cv for not empty
    std::unique_lock lk(m);
    cvNotEmpty.wait(lk,[this]{return int(q.size())>0;});
    // 2. Pop the front item of the queue. The popped item is a vector<char>
    std::vector<char> vec = q.front();
    q.pop();
    // 3. Convert the popped vector<char> into a char*, copy that into msg; assert that the vector<char>'s length is <= size
    // unlock
    lk.unlock();
    assert((int)vec.size() <= size);
    memset(msg,0,size);
    memcpy(msg,vec.data(),vec.size());
    
    // 4. Wake up threads that were waiting for pop //notify 
    cvNotFull.notify_one();
    // 5. Return the vector's length to the caller so that they know how many bytes were popped //actual number of bytes
    return vec.size();
}

size_t BoundedBuffer::size () {
    return q.size();
}
