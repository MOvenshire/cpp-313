/*
	Original author of the starter code
    Tanzir Ahmed
    Department of Computer Science & Engineering
    Texas A&M University
    Date: 2/8/20
	
	Please include your Name, UIN, and the date below
	Name: Marissa Ovenshire
	UIN: 630003497
	Date: 9/10/22
*/
#include "common.h"
#include "FIFORequestChannel.h"
#include <fstream>
#include <sys/wait.h>

using namespace std;


int main (int argc, char *argv[]) {
	//initialize to be invalid to know if user set
	int opt;
	int p = -1;
	double t = -1;
	int e = -1;
	int m = MAX_MESSAGE;
	bool newChan = false;
	string filename = "";

	while ((opt = getopt(argc, argv, "p:t:e:f:m:c")) != -1) {
		switch (opt) {
			case 'p':
				p = atoi (optarg);
				break;
			case 't':
				t = atof (optarg);
				break;
			case 'e':
				e = atoi (optarg);
				break;
			case 'f':
				filename = optarg;
				break;
			case 'c':
				newChan = true;
				break;
			case 'm':
				m = atoi(optarg);
				if(m > MAX_MESSAGE || m < 0)//handle invalid value from user flag
				{
					m = MAX_MESSAGE;
				}
				break;
		}
	}

	vector<FIFORequestChannel*> channels; //initialize vector to keep track of all channels
	//get server running as child 
	int pid = fork();
	if(pid == 0 )
	{
		//in child
		char* cmd[] = {(char*)"-m",(char*)"m",nullptr};
		execvp("./server",cmd); //use array to create server arguments -m 
	}
	else
	{
		//in parent/ client processes
		FIFORequestChannel control("control", FIFORequestChannel::CLIENT_SIDE);
		channels.push_back(&control);
		if(newChan)
		{
			MESSAGE_TYPE nc = NEWCHANNEL_MSG;
			control.cwrite(&nc,sizeof(MESSAGE_TYPE));
			char readBuf[MAX_MESSAGE];
			control.cread(readBuf,sizeof(readBuf));
			FIFORequestChannel* new_chan = new FIFORequestChannel(readBuf,FIFORequestChannel::CLIENT_SIDE);
			channels.push_back(new_chan);
		}
		
		FIFORequestChannel active_chan = *(channels.back());

		//single data point requested
		if(p != -1 && t != -1 && e != -1)
		{
			char buf[MAX_MESSAGE];//256
			datamsg x(p, t, e); //
			memcpy(buf, &x, sizeof(datamsg));
			active_chan.cwrite(buf,sizeof(datamsg)); //question
			double reply;
			active_chan.cread(&reply,sizeof(double)); //answer
			cout << "For person " << p << ", at time " << t << ", the value of ecg " << e << " is " << reply << endl;

		}else if(p != -1) //only person specified give first 1000
		{
			ofstream outfile;
			string  fileToOpen = "received/x1.csv";
			outfile.open(fileToOpen);

			double time = 0.0;
			for(int i = 0; i < 1000; i++)
			{
				//send request ecg1
				datamsg *sendECG1 = new datamsg(p,time,1);
				active_chan.cwrite(sendECG1,sizeof(datamsg));
				double* ecg1  = new double;
				active_chan.cread(ecg1,sizeof(double));
				
				//send request ecg2
				datamsg *sendECG2 = new datamsg(p,time,2);
				active_chan.cwrite(sendECG2,sizeof(datamsg));
				double* ecg2  = new double;
				active_chan.cread(ecg2,sizeof(double));
				
				//write time,ecg1,ecg2 to received/x1.csv
				outfile << time << "," << *ecg1 << "," << *ecg2 << endl;
				time += 0.004;

				delete sendECG1;
				delete sendECG2;
				delete ecg1;
				delete ecg2;
			}
			outfile.close();

		//write patient data
		}else if(filename != "") //condition for sending a file
		{
			filemsg fm(0, 0);
			int len = sizeof(filemsg) + (filename.size() + 1);//+1 for null terminator 
			char* buf2 = new char[len];			
			memcpy(buf2,&fm,sizeof(filemsg));
			strcpy(buf2+sizeof(filemsg),filename.c_str());

			active_chan.cwrite(buf2, len);  // I want the file length; //send to server

			__int64_t file_size;
			active_chan.cread(&file_size,sizeof(__int64_t));

			//write response_buf into file: received/filename
			string filepath = "received/" +filename;

			//open file
			ofstream outfile;
			outfile.open(filepath, ios::out | ios::binary);

			//create filemsg instance 
			filemsg* file_req = (filemsg*)buf2;
			file_req->offset = 0;//set offset in file
			file_req->length = m;//set the length (NOTE last segment is just remainder dont seg fault)
			
			//initialize segments for loop in file aka filsize/buff_capacity(m)
			int numSegments = (file_size / m);
			for(int i = 0; i <= numSegments; i++)
			{	
				if(i == numSegments)
				{
					//handle last segment that isn't full length
					file_req->length = file_size % m;
				}
				char* response_buf = new char[file_req->length];
				active_chan.cwrite(buf2, len);
				active_chan.cread(response_buf, file_req->length);

				outfile.write(response_buf, file_req->length);

				delete[]response_buf;
				
				file_req->offset += m;
			}
			//close file 
			outfile.close();			
			delete[]buf2;
		}
		//close 
		MESSAGE_TYPE m = QUIT_MSG;
    	active_chan.cwrite(&m, sizeof(MESSAGE_TYPE));
	}
	wait(NULL);
}
