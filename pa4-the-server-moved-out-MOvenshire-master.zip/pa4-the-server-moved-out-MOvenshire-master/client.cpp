// your PA3 client code here
//update opt ard for a:r: for ipaddress and port 

#include <fstream>
#include <iostream>
#include <thread>
#include <sys/time.h>
#include <sys/wait.h>

#include "BoundedBuffer.h"
#include "common.h"
#include "Histogram.h"
#include "HistogramCollection.h"
#include "TCPRequestChannel.h"

// ecgno to use for datamsgs
#define EGCNO 1

using namespace std;


void patient_thread_function (int n, int p, BoundedBuffer *requestBuf) {
    // functionality of the patient threads
    //whole goal is put request packets into request buffer 
    //iterate n times for the given patient 
    double t = 0.0;
    for(int i = 0; i<n;i++){
        //create data msg item
        datamsg d1(p, t, 1);
        //push data msg to request buffer
        requestBuf->push((char*)&d1, sizeof(datamsg));
        //increment t by 0.004
        t += 0.004;
    }
}

void file_thread_function (int m, string filename, BoundedBuffer *requestBuf, TCPRequestChannel* chan) {
    // functionality of the file thread
    //like pa1 iterate through file and create file requests
    //if last truncate length 
    //instead of writing to channel, push the packed to request buffer  
    char buf[MAX_MESSAGE];
    filemsg f(0,0);
    memcpy(buf, &f, sizeof(f));
    strcpy(buf+sizeof(f), filename.c_str());
    chan->cwrite(buf, sizeof(f) + filename.size() + 1);
    __int64_t filelength;
    chan->cread(&filelength, sizeof(filelength));
    string filepath = "received/"+filename;
    FILE* fp = fopen(filepath.c_str(), "w");
    fseek (fp, filelength, SEEK_SET);
    fclose (fp);

    filemsg* fm = (filemsg*) buf;
    __int64_t remlen = filelength;

    while(remlen > 0){
        fm->length = min(remlen, (__int64_t) m);
        requestBuf->push(buf, sizeof(filemsg) + filename.size() + 1);
        fm->offset += fm->length;
        remlen -= fm->length;
    }
}

void worker_thread_function ( TCPRequestChannel* chan, BoundedBuffer* requestBuf, BoundedBuffer* respBuf, int m) {
    // functionality of the worker threads
    //only want worker thread to write to control 
    char buf[MAX_MESSAGE];
    double servDouble;
    char readBuf[m];

    //while true
    while(true){
        //pop request from req buffer
        requestBuf->pop(buf, MAX_MESSAGE);
        MESSAGE_TYPE *msg = (MESSAGE_TYPE*) buf;
        //send to server with our channelmsg
        
        if(*msg == FILE_MSG){
            //if message type is file 
            //receive buffer form server
            //write to file
            filemsg* fm = (filemsg*)buf;
            string filename  = (char*) (fm+1); //space for nullterminator
            chan->cwrite(buf,sizeof(filemsg)+filename.size()+1);
            chan->cread(readBuf, m);

            string filepath = "received/"+filename;
            FILE* f = fopen(filepath.c_str(), "r+");
            fseek(f, fm->offset, SEEK_SET);
            fwrite(readBuf, 1, fm->length, f);
            fclose(f);
        }
        
        if(*msg == DATA_MSG){
            //if message type is datamsg
            //receive the double from the server
            //format pair<int,double> and push that to the response buffer
            chan->cwrite(buf, sizeof(datamsg));
            chan->cread(&servDouble, sizeof(double));
            pair<int, double> dataPair;
            dataPair.first = ((datamsg*)buf)->person;
            dataPair.second = servDouble;
            respBuf->push((char*)(&dataPair), sizeof(pair<int, double>));
        }
        
        if(*msg == QUIT_MSG){
            //if message type is quit
            //break
            chan->cwrite(buf, sizeof(QUIT_MSG));
            break;
        }
    }
}

void histogram_thread_function (HistogramCollection *hc, BoundedBuffer * resBuf) {
    // functionality of the histogram threads
    //while true 
    //pop from response buffer
    //call histogram collection update function 
    //cout <<"histogram_thread_funciton starting"<<endl;//DEBUG TRACE
    pair<int, double> dataPair;
    while(true){
        resBuf->pop((char*)&dataPair, sizeof(dataPair));
        if(dataPair.first <=0 ){
            break;
        }
        hc->update(dataPair.first, dataPair.second);
    }
}


int main (int argc, char* argv[]) {
    int n = 1000;	// default number of requests per "patient"
    int p = 10;		// number of patients [1,15]
    int w = 100;	// default number of worker threads
	int h = 20;		// default number of histogram threads
    int b = 20;		// default capacity of the request buffer (should be changed)
	int m = MAX_MESSAGE;	// default capacity of the message buffer
	string f = "";	// name of file to be transferred
    string port = "127.0.0.1"; //defaults based on video
    string ip = "8080"; //default based on video

    
    // read arguments
    int opt;
    
	while ((opt = getopt(argc, argv, "n:p:w:h:b:m:f:a:r:")) != -1) {
		switch (opt) {
			case 'n':
				n = atoi(optarg);
                break;
			case 'p':
				p = atoi(optarg);
                break;
			case 'w':
				w = atoi(optarg);
                break;
			case 'h':
				h = atoi(optarg);
				break;
			case 'b':
				b = atoi(optarg);
                break;
			case 'm':
				m = atoi(optarg);
                break;
			case 'f':
				f = optarg;
                break;
			case 'r':
				port = optarg;
				break;
            case 'a':
                ip = optarg;
                break;
		}
	}
    

    //cout << "STARTING" <<endl;//DEBUG TRACE
	// initialize overhead (including the control channel)
	TCPRequestChannel* chan = new TCPRequestChannel(ip, port);
    BoundedBuffer request_buffer(b);
    BoundedBuffer response_buffer(b);
	HistogramCollection hc;

    //create w number of channels - send new request to server, get name, call constuctor
    //populate vector to hold all channels - use new put them on the heap
    //don't forget to remove
    vector<TCPRequestChannel*> workerChan;
    for(int i = 0;i<w;i++){
        workerChan.push_back(new TCPRequestChannel(ip, port));
    }
    //cout << "Worker Channels created" << endl;//DEBUG TRACE

    // making histograms and adding to collection
    for (int i = 0; i < p; i++) {
        Histogram* h = new Histogram(10, -2.0, 2.0);
        hc.add(h);
    }
	
	// record start time
    struct timeval start, end;
    gettimeofday(&start, 0);

    /* create all threads here */
    vector<std::thread>workerVec;
    vector<std::thread>miscThread;
    vector<std::thread>histThread;
    
    //if file transfer, start file thread
    if(f != ""){
        miscThread.push_back(thread(file_thread_function, m, f, &request_buffer, chan)); 
        //file_thread_function (int m, string filename, BoundedBuffer *requestBuf, FIFORequestChannel* chan)
        //cout << "Filethread created" << endl;//DEBUG TRACE
    }
    if(f == ""){ //if there is not file transfer, it must be patient data transfer
        //if patient data transfer, create p patient threads (-p argument, convert from 0 to 1)
        for(int i = 1; i<=p; i++){
            miscThread.push_back(thread(patient_thread_function, n, i, &request_buffer));//patient_thread_function (int n, int p, BoundedBuffer *requestBuf)
        }
        //cout << "Patient threads created" << endl; //DEBUG TRACE
    }
    
    //start worker threads
    //w num worker threads 
    for(int i = 0; i <  w; i++){
        workerVec.push_back(thread(worker_thread_function, workerChan.at(i), &request_buffer, &response_buffer, m));
        //worker_thread_function (FIFORequestChannel* chan, BoundedBuffer* requestBuf, BoundedBuffer * responseBuf, int m)
    }
    //cout << "Worker threads started" << endl; //DEBUG TRACE

    if(f ==""){ //only create histogram threads for non file transfer
        for(int i = 0; i < h;i++){
            histThread.push_back(thread(histogram_thread_function, &hc, &response_buffer));
        }
    }
    
    /* join all threads here */
    //join file thread or patient threads
    for(int i = 0;i < int(miscThread.size());i++){
        miscThread.at(i).join();
    }
    //cout << "File or patient threads joined" << endl;//DEBUG TRACE

    //send quit message to request buffer  *w to close every thread
    for(int i = 0; i < w; i++){
        MESSAGE_TYPE quit = QUIT_MSG;
        request_buffer.push((char*)&quit, sizeof(quit));
    }
    //cout << "Quit messages sent to request buffer" << endl;//DEBUG TRACE

    
    //join worker threads
    for(int i = 0;i < w;i++){
        workerVec.at(i).join();
    }
    //if data, push number of <-1,-1> pair to the response buffer //h is user input for num histogram 
    if(f ==""){
        for(int i = 0; i<h; i++){
            pair<int, double> dataPair;
            dataPair.first = -1;
            dataPair.second = -1;
            response_buffer.push((char*)(&dataPair), sizeof(pair<int, double>));
        }
        for(int i = 0; i<h;i++){//datamsg also created for patients so histogram threads also need to be made
            histThread.at(i).join();
        }
    }

	// record end time
    gettimeofday(&end, 0);

    // print the results
	if (f == "") {
		hc.print();
	}
    int secs = ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) / ((int) 1e6);
    int usecs = (int) ((1e6*end.tv_sec - 1e6*start.tv_sec) + (end.tv_usec - start.tv_usec)) % ((int) 1e6);
    cout << "Took " << secs << " seconds and " << usecs << " micro seconds" << endl;

	// quit and close control channel
    MESSAGE_TYPE q = QUIT_MSG;
    chan->cwrite ((char *) &q, sizeof (MESSAGE_TYPE));
    cout << "All Done!" << endl;
    delete chan;

    //delete all worker channels
    for(int i =0; i<w; i++){
        delete workerChan.at(i);
    }

	// wait for server to exit
	wait(nullptr);
}
