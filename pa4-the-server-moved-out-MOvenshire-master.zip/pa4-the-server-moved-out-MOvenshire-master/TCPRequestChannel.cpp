#include "TCPRequestChannel.h"
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>

using namespace std;

#define BACKLOG 10
TCPRequestChannel::TCPRequestChannel (const std::string _ip_address, const std::string _port_no) {
    //tcp request channel class (2)
    //server side
    //open bind
    //getaddrinfo (host name, port num, where its from, where it goes)
    //socket
    //bind
    //must have same port number

    //beej 9 go to example accept
    //AF_INET instead of AF_UNSPEC
    if(_ip_address.empty()){
        //server
        //code from beej 9 
        struct addrinfo hints, *res;

        //first, load up address structs with getaddrinfo()
        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_INET; //use IPv4 
        hints.ai_socktype = SOCK_STREAM;
        hints.ai_flags = AI_PASSIVE; // fill in my IP for me

        getaddrinfo(NULL, _port_no.c_str(), &hints, &res);
        //make socket, bind it, and listen to it
        sockfd = socket(res->ai_family,res->ai_socktype, res->ai_protocol);
        bind(sockfd, res->ai_addr, res->ai_addrlen);
        listen(sockfd, BACKLOG);
        freeaddrinfo(res);

    }
    else{
        //client
        //beej connect example 
        // connect to www.example.com port 80 (http)

        struct addrinfo hints, *res;

        // first, load up address structs with getaddrinfo():

        memset(&hints, 0, sizeof hints);
        hints.ai_family = AF_INET;  // use IPv4 or IPv6, whichever
        hints.ai_socktype = SOCK_STREAM;

        // we could put "80" instead on "http" on the next line:
        getaddrinfo(_ip_address.c_str(), _port_no.c_str(), &hints, &res);

        // make a socket:

        sockfd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);

        // connect it to the address and port we passed in to getaddrinfo():

        connect(sockfd, res->ai_addr, res->ai_addrlen);
        freeaddrinfo(res);
    }
}

TCPRequestChannel::TCPRequestChannel (int _sockfd) {
    sockfd = _sockfd;
}

TCPRequestChannel::~TCPRequestChannel () {
    close(sockfd);
}

int TCPRequestChannel::accept_conn () {
    struct sockaddr_storage their_addr;
    socklen_t addr_size;
    int new_fd;
    // now accept an incoming connection:

    addr_size = sizeof their_addr;
    new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &addr_size);

    return new_fd;
}

int TCPRequestChannel::cread (void* msgbuf, int msgsize) {
    return read(sockfd, msgbuf, msgsize);
}

int TCPRequestChannel::cwrite (void* msgbuf, int msgsize) {
    return write(sockfd, msgbuf, msgsize);
}
