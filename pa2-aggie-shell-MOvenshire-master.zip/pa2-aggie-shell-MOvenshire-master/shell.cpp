#include <iostream>

#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include <fcntl.h> //open(), O_RDONLY, O_WRONLY 

#include <vector>
#include <string>

#include "Tokenizer.h"


// all the basic colours for a shell prompt
#define RED     "\033[1;31m"
#define GREEN	"\033[1;32m"
#define YELLOW  "\033[1;33m"
#define BLUE	"\033[1;34m"
#define WHITE	"\033[1;37m"
#define NC      "\033[0m"

using namespace std;

int main () {
    vector<pid_t> backgrounds; //create vector pids
    vector<string> directories;//keep track of past directories
    int status;
    int old_stdin = dup(0);
    int old_stdout = dup(1);

    for (;;) { //infinite loop - loop 1 
        // need date/time, username, and absolute path to current dir
        char s[256];
        time_t curr = time(NULL);
        struct tm*p = localtime(&curr);
        strftime(s, 30,"%b %d %T",p);
        
        //used time/ local time 
        char absPathBuf[1000];
	    getcwd(absPathBuf, sizeof(absPathBuf));
        cout <<YELLOW<<s<<" "<< getenv("USER")<<":"<< absPathBuf<< "$" << NC << " ";

        for(pid_t back_p:backgrounds)
        {
            waitpid(back_p, &status, WNOHANG);
        }

        // get user inputted command
        string input;
        getline(cin, input);

        if (input == "exit") {  // print exit message and break out of infinite loop
            cout << RED << "Now exiting shell..." << endl << "Goodbye" << NC << endl;
            break;
        }

        // get tokenized commands from user input
        Tokenizer tknr(input);
        if (tknr.hasError()) {  // continue to next prompt if input had an error
            continue;
        }

        //Directory handling
        if(input.find("cd")!= std::string::npos)
        {
            //save old directory
            directories.push_back(absPathBuf);
            chdir(tknr.commands.at(0)->args.at(1).c_str()); //change into the args[1];
            
            if((tknr.commands.at(0)->args.at(1))=="-")//if args[1] is "-", go into old directory 
            {
                chdir((directories.at(directories.size()-2)).c_str());
            }
            continue; //dont want to fork bomb don't put in parent or child
        }

        //note up arrow ^[[A left arror ^[[D right ^[[C 

        for(long unsigned int i = 0; i<tknr.commands.size();i++)//iterate through commands loop 2
        {
            int pipefds[2];
            pipe(pipefds);

            int pid = fork();
            if (pid < 0) {  // error check
                perror("fork");
                exit(2);
            }
            if(pid == 0)
            {
                //Child
                //redirect output to write end of pipe - not if last command
                if(i!=(tknr.commands.size()-1))
                {//for last command don't redirect output for P3 (if statement don't redirect to parent -> redirect to terminal)
                    dup2(pipefds[1],STDOUT_FILENO); //from le1 STDOUT_FILENO/ write = 1
                }
                //close read end of pipe
                close(pipefds[0]);
                
                //to use execvp turn into pointer
                char** args = new char*[tknr.commands[i]->args.size()+1];
                
                for(long unsigned int j = 0; j < tknr.commands[i]->args.size();j++)//interate over all the arguments in token.commands[i] - loop 3
                {
                    args[j] = (char*)tknr.commands[i]->args[j].c_str();
                    
                }//end loop 3
                args[tknr.commands[i]->args.size()]= nullptr;

                //handle file output redirection
                if(tknr.commands.at(i)->hasOutput())
                {
                    int fd = open(tknr.commands.at(i)->out_file.c_str(), O_WRONLY | O_CREAT | O_TRUNC, 0666);
                    dup2(fd,1);
                }
                //handle file input redirection 
                if(tknr.commands.at(i)->hasInput())
                {
                    int fd = open(tknr.commands.at(i)->in_file.c_str(), O_RDONLY, 0666);
                    dup2(fd,0);
                }
                
                //call execvp on token.commands[i]->args
                if (execvp(args[0], args) < 0) {  // error check
                    perror("execvp");
                    exit(2);
                }
                delete[]args;
            }else
            {
                //Parent
                status = 0;
                //redirect stdin to read end of the 
                dup2(pipefds[0],STDIN_FILENO); //from le1 STDIN_FILENO/ read = 0
                //close the write end of the pipe
                close(pipefds[1]);

                //if last command, waitpid(pid, NULL, 0) on the pid from fork
                if(i==(tknr.commands.size()-1))
                {
                    if(!tknr.commands.at(i)->isBackground())
                    {
                        waitpid(pid, &status, 0);
                    }
                    else
                    {
                        //add pid to pids vector to kill later and not leave zombie
                        backgrounds.push_back(pid);
                    }
                }
                
                if (status > 1) {  // exit if child didn't exec properly
                    exit(status);
                }

            }
        }//close loop 2

        //restore stdin(0) and stdout(1) to old_stdin
        dup2(old_stdin,0);
        dup2(old_stdout,1);

    }
}
